<template>
</template>

<style scoped>
p {
    display: flex;
    justify-content: center;
    color: black;
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
    font-size: x-large;
}
</style>